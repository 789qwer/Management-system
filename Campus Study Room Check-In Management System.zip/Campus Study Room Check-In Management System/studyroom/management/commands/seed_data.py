"""初始化示例数据：图书与饮品。仅当对应表为空时写入，可重复执行。"""
from django.core.management.base import BaseCommand

from studyroom.models import Book, Drink

BOOKS = [
    ('Python编程：从入门到实践', '埃里克·马瑟斯', '9787115428028', 'computer', '人民邮电出版社', 5, '图书馆A区-1排-1架',
     '针对所有层次Python学习者的入门书，通过项目实践掌握编程基础。'),
    ('深入理解计算机系统', 'Randal E. Bryant', '9787111544937', 'computer', '机械工业出版社', 3, '图书馆A区-1排-2架',
     '从程序员的视角详细阐述计算机系统的本质概念。'),
    ('算法导论', 'Thomas H. Cormen', '9787111407010', 'computer', '机械工业出版社', 2, '图书馆A区-1排-3架',
     '算法领域的经典巨著，全面论述算法设计与分析。'),
    ('机器学习', '周志华', '9787302423287', 'computer', '清华大学出版社', 4, '图书馆A区-2排-1架',
     '西瓜书：机器学习领域经典的入门教材。'),
    ('三体', '刘慈欣', '9787536692930', 'literature', '重庆出版社', 6, '图书馆B区-1排-1架',
     '亚洲首部雨果奖获奖作品，中国科幻文学的里程碑。'),
    ('活着', '余华', '9787506365437', 'literature', '作家出版社', 4, '图书馆B区-1排-2架',
     '讲述了人如何去承受巨大的苦难，讲述了眼泪的宽广和丰富。'),
    ('百年孤独', '加西亚·马尔克斯', '9787544253994', 'literature', '南海出版公司', 3, '图书馆B区-2排-1架',
     '魔幻现实主义文学的代表作，融入神话传说与民间故事。'),
    ('时间简史', '史蒂芬·霍金', '9787535732309', 'science', '湖南科学技术出版社', 4, '图书馆C区-1排-1架',
     '探索时间和空间核心秘密的科普经典。'),
    ('人类简史', '尤瓦尔·赫拉利', '9787508647357', 'science', '中信出版社', 5, '图书馆C区-1排-2架',
     '从认知革命、农业革命到科学革命，讲述人类的大历史。'),
    ('机器人学导论', 'John J. Craig', '9787111398479', 'science', '机械工业出版社', 2, '图书馆C区-2排-1架',
     '机器人运动学、动力学与控制的经典教材。'),
    ('国富论', '亚当·斯密', '9787100043070', 'economy', '商务印书馆', 2, '图书馆D区-1排-1架',
     '现代经济学的开山之作，系统阐述国民财富的性质与原因。'),
    ('经济学原理', '曼昆', '9787301231497', 'economy', '北京大学出版社', 3, '图书馆D区-1排-2架',
     '以通俗易懂的方式讲解经济学十大原理。'),
    ('牛津高阶英汉双解词典', '霍恩比', '9787100174187', 'foreign', '商务印书馆', 3, '图书馆E区-1排-1架',
     '英语学习者的权威工具书。'),
]

DRINKS = [
    ('美式咖啡', 'coffee', 12.00, '经典浓缩，香醇回甘'),
    ('拿铁', 'coffee', 15.00, '浓缩与牛奶的丝滑融合'),
    ('卡布奇诺', 'coffee', 16.00, '绵密奶泡，浓郁咖啡香'),
    ('摩卡', 'coffee', 18.00, '巧克力与咖啡的甜蜜邂逅'),
    ('龙井茶', 'tea', 10.00, '清新鲜爽，回甘悠长'),
    ('茉莉花茶', 'tea', 8.00, '花香四溢，清新怡人'),
    ('锡兰红茶', 'tea', 8.00, '茶香浓郁，暖胃提神'),
    ('鲜榨橙汁', 'juice', 14.00, '现点现榨，维C满满'),
    ('芒果汁', 'juice', 15.00, '香甜浓郁，果肉细腻'),
    ('曲奇饼干', 'snack', 6.00, '黄油曲奇，酥脆可口'),
    ('提拉米苏', 'snack', 12.00, '经典意式甜品，咖啡与芝士的完美结合'),
]


class Command(BaseCommand):
    help = '初始化示例数据（图书、饮品），仅在对应表为空时写入'

    def handle(self, *args, **options):
        if Book.objects.exists():
            self.stdout.write(self.style.WARNING('图书数据已存在，跳过'))
        else:
            for title, author, isbn, category, publisher, copies, location, desc in BOOKS:
                Book.objects.create(
                    title=title, author=author, isbn=isbn, category=category,
                    publisher=publisher, total_copies=copies, available_copies=copies,
                    location=location, description=desc,
                )
            self.stdout.write(self.style.SUCCESS(f'已写入 {len(BOOKS)} 种示例图书'))

        if Drink.objects.exists():
            self.stdout.write(self.style.WARNING('饮品数据已存在，跳过'))
        else:
            for name, category, price, desc in DRINKS:
                Drink.objects.create(name=name, category=category, price=price, description=desc)
            self.stdout.write(self.style.SUCCESS(f'已写入 {len(DRINKS)} 种示例饮品'))
