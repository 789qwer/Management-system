"""App 路由。"""
from django.urls import path

from . import views

urlpatterns = [
    # 公共页面
    path('', views.home, name='home'),
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),

    # 学生侧
    path('profile/', views.profile_view, name='profile'),
    path('rooms/', views.room_list, name='room_list'),
    path('rooms/<int:room_id>/', views.room_detail, name='room_detail'),
    path('reserve/<int:seat_id>/', views.reserve_seat, name='reserve_seat'),
    path('reservation/<int:reservation_id>/sign-in/', views.sign_in, name='sign_in'),
    path('reservation/<int:reservation_id>/sign-out/', views.sign_out, name='sign_out'),
    path('reservation/<int:reservation_id>/cancel/', views.cancel_reservation, name='cancel_reservation'),

    # 学生侧 - 图书借阅
    path('books/', views.book_list, name='book_list'),
    path('books/<int:book_id>/', views.book_detail, name='book_detail'),
    path('books/<int:book_id>/borrow/', views.borrow_book, name='borrow_book'),
    path('borrows/', views.my_borrows, name='my_borrows'),
    path('borrows/<int:record_id>/return/', views.return_book, name='return_book'),
    path('borrows/<int:record_id>/renew/', views.renew_book, name='renew_book'),

    # 学生侧 - 饮品吧
    path('cafe/', views.cafe, name='cafe'),
    path('cafe/<int:drink_id>/order/', views.order_drink, name='order_drink'),
    path('orders/', views.my_orders, name='my_orders'),
    path('orders/<int:order_id>/cancel/', views.cancel_drink_order, name='cancel_drink_order'),

    # 管理员 - 仪表盘
    path('manage/dashboard/', views.admin_dashboard, name='admin_dashboard'),

    # 管理员 - 用户管理
    path('manage/users/', views.user_list, name='user_list'),
    path('manage/users/add/', views.user_add, name='user_add'),
    path('manage/users/<int:user_id>/edit/', views.user_edit, name='user_edit'),
    path('manage/users/<int:user_id>/delete/', views.user_delete, name='user_delete'),
    path('manage/users/<int:user_id>/reset-password/', views.user_reset_password, name='user_reset_password'),

    # 管理员 - 自习室管理
    path('manage/rooms/', views.manage_rooms, name='manage_rooms'),
    path('manage/rooms/add/', views.add_room, name='add_room'),
    path('manage/rooms/<int:room_id>/edit/', views.edit_room, name='edit_room'),
    path('manage/rooms/<int:room_id>/delete/', views.delete_room, name='delete_room'),

    # 管理员 - 座位管理
    path('manage/rooms/<int:room_id>/seats/', views.seat_manage, name='seat_manage'),
    path('manage/rooms/<int:room_id>/seats/add/', views.seat_add, name='seat_add'),
    path('manage/seats/<int:seat_id>/edit/', views.seat_edit, name='seat_edit'),
    path('manage/seats/<int:seat_id>/delete/', views.seat_delete, name='seat_delete'),

    # 管理员 - 预约记录
    path('manage/reservations/', views.reservation_records, name='reservation_records'),
    path('manage/reservations/<int:reservation_id>/delete/', views.delete_reservation, name='delete_reservation'),

    # 管理员 - 违规管理
    path('manage/violations/', views.violation_list, name='violation_list'),
    path('manage/violations/add/', views.violation_add, name='violation_add'),
    path('manage/violations/<int:violation_id>/delete/', views.violation_delete, name='violation_delete'),

    # 管理员 - 图书管理
    path('manage/books/', views.manage_books, name='manage_books'),
    path('manage/books/add/', views.add_book, name='add_book'),
    path('manage/books/<int:book_id>/edit/', views.edit_book, name='edit_book'),
    path('manage/books/<int:book_id>/delete/', views.delete_book, name='delete_book'),
    path('manage/borrows/', views.borrow_records, name='borrow_records'),

    # 管理员 - 饮品管理
    path('manage/drinks/', views.manage_drinks, name='manage_drinks'),
    path('manage/drinks/add/', views.add_drink, name='add_drink'),
    path('manage/drinks/<int:drink_id>/edit/', views.edit_drink, name='edit_drink'),
    path('manage/drinks/<int:drink_id>/delete/', views.delete_drink, name='delete_drink'),
    path('manage/orders/', views.drink_orders, name='drink_orders'),
    path('manage/orders/<int:order_id>/complete/', views.drink_order_complete, name='drink_order_complete'),
]
