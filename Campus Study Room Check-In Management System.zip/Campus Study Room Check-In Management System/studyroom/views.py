"""视图函数 - 校园自习室签到管理系统。"""
import random
import string
from datetime import datetime, timedelta

from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required, user_passes_test
from django.db.models import Count, Q
from django.db import transaction
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone

from .forms import (
    BookForm,
    DrinkForm,
    PasswordResetForm,
    ReservationForm,
    SeatForm,
    StudyRoomForm,
    UserAddForm,
    UserEditForm,
    UserRegistrationForm,
    ViolationForm,
)
from .models import (
    Book,
    BorrowRecord,
    Drink,
    DrinkOrder,
    Reservation,
    Seat,
    StudyRoom,
    User,
    Violation,
)


def is_admin(user):
    """角色判断：管理员。"""
    return user.is_authenticated and user.is_admin_role


def _generate_captcha(length=4):
    """生成随机验证码（大写字母+数字，排除易混淆字符）。"""
    chars = ''.join(set(string.ascii_uppercase + string.digits) - set('IO01'))
    return ''.join(random.choices(chars, k=length))


# ================================================================
#  公共页面
# ================================================================

def home(request):
    if request.user.is_authenticated:
        rooms = StudyRoom.objects.filter(status='open')
        ctx = {
            'rooms': rooms,
            'room_count': rooms.count(),
            'available_seats': Seat.objects.filter(status='available').count(),
            'book_count': Book.objects.count(),
            'drink_count': Drink.objects.filter(is_available=True).count(),
            'borrowing_count': BorrowRecord.objects.filter(
                user=request.user, status='borrowing').count(),
            'pending_orders': DrinkOrder.objects.filter(
                user=request.user, status='pending').count(),
            'recent_books': Book.objects.order_by('-created_at')[:4],
        }
        return render(request, 'studyroom/home.html', ctx)
    # 未登录：展示介绍页
    stats = {
        'room_count': StudyRoom.objects.filter(status='open').count(),
        'seat_count': Seat.objects.filter(status='available').count(),
        'user_count': User.objects.filter(role='student').count(),
    }
    return render(request, 'studyroom/landing.html', {'stats': stats})


def register_view(request):
    """注册视图：含图形验证码校验。"""
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        # 验证码校验（在表单验证通过后再校验，也可独立校验）
        input_captcha = request.POST.get('captcha', '').strip().upper()
        session_captcha = request.session.get('register_captcha', '').upper()
        if not input_captcha:
            form.add_error('captcha', '请输入验证码')
        elif input_captcha != session_captcha:
            form.add_error('captcha', '验证码错误')
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, '注册成功，欢迎使用！')
            return redirect('home')
    else:
        form = UserRegistrationForm()

    # 每次渲染都生成新验证码（GET 首次 / POST 失败刷新）
    captcha_code = _generate_captcha()
    request.session['register_captcha'] = captcha_code
    return render(request, 'studyroom/register.html', {
        'form': form,
        'captcha_code': captcha_code,
    })


def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            messages.success(request, f'欢迎回来，{user.username}！')
            if user.is_admin_role:
                return redirect('admin_dashboard')
            return redirect('home')
        messages.error(request, '用户名或密码错误')
    return render(request, 'studyroom/login.html')


def logout_view(request):
    """退出登录：同时支持 GET/POST，登出后跳转登录页。"""
    logout(request)
    messages.info(request, '您已安全退出登录')
    return redirect('login')


# ================================================================
#  学生侧
# ================================================================

@login_required
def profile_view(request):
    from django.db.models import DurationField, ExpressionWrapper, F, Sum
    reservations = Reservation.objects.filter(user=request.user).select_related('seat__room').order_by('-created_at')[:10]
    violations = Violation.objects.filter(user=request.user)
    total_reservations = Reservation.objects.filter(user=request.user, status='completed').count()
    active_count = Reservation.objects.filter(user=request.user, status='active').count()
    pending_count = Reservation.objects.filter(user=request.user, status='pending').count()
    noshow_count = Reservation.objects.filter(user=request.user, status='noshow').count()
    # 数据库聚合计算累计学习时长
    agg = Reservation.objects.filter(
        user=request.user, status='completed',
        sign_in_time__isnull=False, sign_out_time__isnull=False,
    ).annotate(
        duration=ExpressionWrapper(F('sign_out_time') - F('sign_in_time'), output_field=DurationField())
    ).aggregate(total=Sum('duration'))
    total_hours = agg['total'].total_seconds() / 3600 if agg['total'] else 0
    # 借阅与饮品统计
    borrowing_count = BorrowRecord.objects.filter(user=request.user, status='borrowing').count()
    pending_order_count = DrinkOrder.objects.filter(user=request.user, status='pending').count()
    return render(request, 'studyroom/profile.html', {
        'reservations': reservations,
        'violations': violations,
        'violation_count': violations.count(),
        'total_reservations': total_reservations,
        'active_count': active_count,
        'pending_count': pending_count,
        'noshow_count': noshow_count,
        'total_hours': round(total_hours, 1),
        'borrowing_count': borrowing_count,
        'pending_order_count': pending_order_count,
    })


@login_required
def room_list(request):
    rooms = StudyRoom.objects.all().annotate(
        seat_count=Count('seats'),
        occupied_count=Count('seats', filter=Q(seats__status__in=['reserved', 'occupied']))
    )
    return render(request, 'studyroom/room_list.html', {'rooms': rooms})


@login_required
def room_detail(request, room_id):
    room = get_object_or_404(StudyRoom, id=room_id)
    date_str = request.GET.get('date')
    try:
        date = datetime.strptime(date_str, '%Y-%m-%d').date() if date_str else timezone.now().date()
    except ValueError:
        date = timezone.now().date()
    reservations = Reservation.objects.filter(seat__room=room, date=date).exclude(status='cancelled')
    reserved_seat_ids = set(reservations.values_list('seat_id', flat=True))
    seats = list(room.seats.all().order_by('position_y', 'position_x'))
    for s in seats:
        s.is_reserved = s.id in reserved_seat_ids

    return render(request, 'studyroom/room_detail.html', {
        'room': room,
        'seats': seats,
        'shelves': room.shelves if isinstance(room.shelves, list) else [],
        'date': date,
        'reserved_seat_ids': reserved_seat_ids,
        'available_count': len(seats) - len(reserved_seat_ids),
        'total_count': len(seats),
        'reserved_count': len(reserved_seat_ids),
    })


@login_required
def reserve_seat(request, seat_id):
    seat = get_object_or_404(Seat, id=seat_id)
    if request.method == 'POST':
        form = ReservationForm(request.POST)
        if form.is_valid():
            r = form.save(commit=False)
            r.user = request.user
            r.seat = seat
            if r.start_time >= r.end_time:
                messages.error(request, '结束时间必须晚于开始时间')
            elif Reservation.objects.filter(
                seat=seat, date=r.date, status__in=['pending', 'active']
            ).filter(
                start_time__lt=r.end_time, end_time__gt=r.start_time
            ).exists():
                messages.error(request, '该时段座位已被预约')
            elif r.start_time < seat.room.open_time or r.end_time > seat.room.close_time:
                messages.error(request, f'预约时段需在自习室开放时间内（{seat.room.open_time}~{seat.room.close_time}）')
            else:
                r.save()
                seat.status = 'reserved'
                seat.save()
                messages.success(request, '预约成功，请在开始前 15~30 分钟内签到')
                return redirect('profile')
    else:
        form = ReservationForm()
    return render(request, 'studyroom/reserve.html', {'form': form, 'seat': seat})


@login_required
def sign_in(request, reservation_id):
    r = get_object_or_404(Reservation, id=reservation_id, user=request.user)
    if r.status != 'pending':
        messages.error(request, '该预约无法签到')
        return redirect('profile')
    now = timezone.now()
    start_dt = timezone.make_aware(datetime.combine(r.date, r.start_time))
    window_start = start_dt - timedelta(minutes=15)
    window_end = start_dt + timedelta(minutes=30)
    if not (window_start <= now <= window_end):
        messages.error(request, '不在签到时间范围内（开始前15分钟至开始后30分钟）')
        return redirect('profile')
    r.sign_in_time = now
    r.status = 'active'
    r.save()
    r.seat.status = 'occupied'
    r.seat.save()
    messages.success(request, '签到成功！')
    return redirect('profile')


@login_required
def sign_out(request, reservation_id):
    r = get_object_or_404(Reservation, id=reservation_id, user=request.user)
    if r.status != 'active':
        messages.error(request, '该预约无法签退')
        return redirect('profile')
    r.sign_out_time = timezone.now()
    r.status = 'completed'
    r.save()
    r.seat.status = 'available'
    r.seat.save()
    messages.success(request, '签退成功！')
    return redirect('profile')


@login_required
def cancel_reservation(request, reservation_id):
    r = get_object_or_404(Reservation, id=reservation_id, user=request.user)
    if r.status != 'pending':
        messages.error(request, '当前状态无法取消')
        return redirect('profile')
    r.status = 'cancelled'
    r.save()
    r.seat.status = 'available'
    r.seat.save()
    messages.success(request, '已取消预约')
    return redirect('profile')


# ================================================================
#  学生侧 - 图书借阅
# ================================================================

@login_required
def book_list(request):
    """图书检索：关键字 + 分类筛选，分页。"""
    from django.core.paginator import Paginator
    q = request.GET.get('q', '').strip()
    category = request.GET.get('category', '')
    books = Book.objects.all()
    if q:
        books = books.filter(Q(title__icontains=q) | Q(author__icontains=q) | Q(isbn__icontains=q))
    if category:
        books = books.filter(category=category)
    borrowed_book_ids = set(
        BorrowRecord.objects.filter(user=request.user, status='borrowing')
        .values_list('book_id', flat=True)
    )
    page_obj = Paginator(books, 12).get_page(request.GET.get('page'))
    return render(request, 'studyroom/books.html', {
        'page_obj': page_obj,
        'books': page_obj,
        'q': q,
        'category': category,
        'categories': Book.CATEGORY_CHOICES,
        'borrowed_book_ids': borrowed_book_ids,
    })


@login_required
def book_detail(request, book_id):
    book = get_object_or_404(Book, id=book_id)
    my_record = BorrowRecord.objects.filter(
        user=request.user, book=book, status='borrowing').first()
    related_books = Book.objects.filter(category=book.category).exclude(id=book.id)[:4]
    return render(request, 'studyroom/book_detail.html', {
        'book': book,
        'my_record': my_record,
        'related_books': related_books,
    })


@login_required
def borrow_book(request, book_id):
    """借书：事务 + 行锁，防止并发超卖。"""
    if request.method != 'POST':
        return redirect('book_detail', book_id=book_id)
    try:
        with transaction.atomic():
            book = Book.objects.select_for_update().get(id=book_id)
            if book.available_copies <= 0:
                messages.error(request, f'《{book.title}》已全部借出，请稍后再试')
            elif BorrowRecord.objects.filter(user=request.user, book=book, status='borrowing').exists():
                messages.error(request, '你已借阅此书且尚未归还')
            else:
                BorrowRecord.objects.create(
                    user=request.user,
                    book=book,
                    due_at=timezone.now() + timedelta(days=14),
                )
                book.available_copies -= 1
                book.save(update_fields=['available_copies'])
                messages.success(request, f'借阅成功！《{book.title}》请在 14 天内归还')
    except Book.DoesNotExist:
        messages.error(request, '图书不存在')
    return redirect('book_detail', book_id=book_id)


@login_required
def return_book(request, record_id):
    """还书：事务 + 行锁。"""
    record = get_object_or_404(BorrowRecord, id=record_id, user=request.user)
    if request.method == 'POST' and record.status == 'borrowing':
        with transaction.atomic():
            book = Book.objects.select_for_update().get(id=record.book_id)
            record.returned_at = timezone.now()
            record.status = 'returned'
            record.save(update_fields=['returned_at', 'status'])
            book.available_copies += 1
            book.save(update_fields=['available_copies'])
        messages.success(request, f'《{record.book.title}》已归还，感谢使用！')
    return redirect('my_borrows')


@login_required
def renew_book(request, record_id):
    """续借：顺延 14 天，最多 2 次。"""
    record = get_object_or_404(BorrowRecord, id=record_id, user=request.user)
    if request.method == 'POST' and record.status == 'borrowing':
        if record.renew_count >= 2:
            messages.error(request, '已达最大续借次数（2 次），请尽快归还')
        else:
            record.due_at += timedelta(days=14)
            record.renew_count += 1
            record.save(update_fields=['due_at', 'renew_count'])
            messages.success(request, f'续借成功，新还书日期：{record.due_at.strftime("%Y-%m-%d")}（剩余 {2 - record.renew_count} 次续借）')
    return redirect('my_borrows')


@login_required
def my_borrows(request):
    from django.core.paginator import Paginator
    records = BorrowRecord.objects.filter(user=request.user).select_related('book')
    page_obj = Paginator(records, 10).get_page(request.GET.get('page'))
    return render(request, 'studyroom/my_borrows.html', {
        'records': page_obj,
        'page_obj': page_obj,
    })


# ================================================================
#  学生侧 - 饮品吧
# ================================================================

@login_required
def cafe(request):
    drinks = Drink.objects.filter(is_available=True)
    pending_orders = DrinkOrder.objects.filter(user=request.user, status='pending').count()
    return render(request, 'studyroom/cafe.html', {
        'drinks': drinks,
        'pending_orders': pending_orders,
        'sugar_choices': DrinkOrder.SUGAR_CHOICES,
        'temp_choices': DrinkOrder.TEMP_CHOICES,
    })


@login_required
def order_drink(request, drink_id):
    """下单饮品：支持甜度、温度选择，生成取餐码。"""
    drink = get_object_or_404(Drink, id=drink_id, is_available=True)
    if request.method == 'POST':
        try:
            quantity = max(1, min(10, int(request.POST.get('quantity', 1))))
        except (TypeError, ValueError):
            quantity = 1
        note = request.POST.get('note', '').strip()[:100]
        # 甜度与温度（小食无此选项，留空字符串）
        sweetness = request.POST.get('sweetness', 'half_sugar')
        temperature = request.POST.get('temperature', 'normal_ice')
        if drink.category == 'snack':
            sweetness = ''
            temperature = ''
        order = DrinkOrder.objects.create(
            user=request.user,
            drink=drink,
            quantity=quantity,
            sweetness=sweetness,
            temperature=temperature,
            total_price=drink.price * quantity,
            pickup_code=str(random.randint(1000, 9999)),
            note=note,
        )
        messages.success(request, f'下单成功！取餐码 {order.pickup_code}，请凭码到吧台取餐')
    return redirect('cafe')


@login_required
def cancel_drink_order(request, order_id):
    order = get_object_or_404(DrinkOrder, id=order_id, user=request.user)
    if request.method == 'POST' and order.status == 'pending':
        order.status = 'cancelled'
        order.save()
        messages.success(request, '订单已取消')
    return redirect('my_orders')


@login_required
def my_orders(request):
    from django.core.paginator import Paginator
    orders = DrinkOrder.objects.filter(user=request.user).select_related('drink')
    page_obj = Paginator(orders, 10).get_page(request.GET.get('page'))
    return render(request, 'studyroom/my_orders.html', {
        'orders': page_obj,
        'page_obj': page_obj,
    })


# ================================================================
#  管理员侧 - 仪表盘
# ================================================================

@user_passes_test(is_admin)
def admin_dashboard(request):
    today = timezone.now().date()
    room_stats = []
    for room in StudyRoom.objects.all():
        total = room.seats.count()
        used = Reservation.objects.filter(
            seat__room=room, date=today, status__in=['pending', 'active']
        ).count()
        rate = round(used / total * 100, 1) if total else 0
        if rate > 80:
            bar_class = 'bg-danger'
        elif rate > 50:
            bar_class = 'bg-warning'
        elif rate > 0:
            bar_class = 'bg-success'
        else:
            bar_class = 'bg-secondary'
        room_stats.append({
            'room': room, 'used': used, 'total': total, 'rate': rate,
            'available': total - used, 'bar_class': bar_class,
        })
    # 今日预约时间线
    today_reservations = Reservation.objects.filter(
        date=today
    ).select_related('user', 'seat', 'seat__room').order_by('start_time')
    # 最近注册用户
    recent_users = User.objects.filter(role='student').order_by('-date_joined')[:5]
    # 近7天预约趋势
    trend = []
    for i in range(6, -1, -1):
        d = today - timedelta(days=i)
        cnt = Reservation.objects.filter(date=d).count()
        bar_height = min(cnt * 10, 100) if cnt > 0 else 4
        trend.append({'date': d, 'count': cnt, 'bar_height': bar_height})
    ctx = {
        'total_users': User.objects.filter(role='student').count(),
        'total_rooms': StudyRoom.objects.count(),
        'total_seats': Seat.objects.count(),
        'available_seats': Seat.objects.filter(status='available').count(),
        'today_reservations': Reservation.objects.filter(date=today).count(),
        'active_reservations': Reservation.objects.filter(status='active').count(),
        'pending_reservations': Reservation.objects.filter(status='pending').count(),
        'completed_today': Reservation.objects.filter(date=today, status='completed').count(),
        'total_violations': Violation.objects.count(),
        'total_books': Book.objects.count(),
        'borrowing_count': BorrowRecord.objects.filter(status='borrowing').count(),
        'overdue_count': BorrowRecord.objects.filter(status='borrowing', due_at__lt=timezone.now()).count(),
        'total_drinks': Drink.objects.count(),
        'today_orders': DrinkOrder.objects.filter(created_at__date=today).exclude(status='cancelled').count(),
        'room_stats': room_stats,
        'today_reservations_list': today_reservations[:8],
        'recent_users': recent_users,
        'trend': trend,
        'now': timezone.now(),
    }
    return render(request, 'studyroom/admin/dashboard.html', ctx)


# ================================================================
#  管理员侧 - 用户管理（增删改查）
# ================================================================

@user_passes_test(is_admin)
def user_list(request):
    q = request.GET.get('q', '').strip()
    role_filter = request.GET.get('role', '')
    users = User.objects.all().order_by('-date_joined')
    if q:
        users = users.filter(Q(username__icontains=q) | Q(student_id__icontains=q) | Q(college__icontains=q))
    if role_filter:
        users = users.filter(role=role_filter)
    return render(request, 'studyroom/admin/user_list.html', {
        'users': users, 'q': q, 'role_filter': role_filter,
    })


@user_passes_test(is_admin)
def user_add(request):
    if request.method == 'POST':
        form = UserAddForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, '用户创建成功')
            return redirect('user_list')
    else:
        form = UserAddForm()
    return render(request, 'studyroom/admin/user_form.html', {'form': form, 'mode': 'add'})


@user_passes_test(is_admin)
def user_edit(request, user_id):
    target = get_object_or_404(User, id=user_id)
    if request.method == 'POST':
        form = UserEditForm(request.POST, instance=target)
        if form.is_valid():
            form.save()
            messages.success(request, '用户信息已更新')
            return redirect('user_list')
    else:
        form = UserEditForm(instance=target)
    return render(request, 'studyroom/admin/user_form.html', {'form': form, 'mode': 'edit', 'target': target})


@user_passes_test(is_admin)
def user_delete(request, user_id):
    target = get_object_or_404(User, id=user_id)
    if target.is_superuser:
        messages.error(request, '不可删除超级管理员')
        return redirect('user_list')
    if request.method == 'POST':
        target.delete()
        messages.success(request, '用户已删除')
        return redirect('user_list')
    return render(request, 'studyroom/admin/user_confirm_delete.html', {'target': target})


@user_passes_test(is_admin)
def user_reset_password(request, user_id):
    target = get_object_or_404(User, id=user_id)
    if request.method == 'POST':
        form = PasswordResetForm(request.POST)
        if form.is_valid():
            target.set_password(form.cleaned_data['new_password'])
            target.save()
            messages.success(request, f'已重置 {target.username} 的密码')
            return redirect('user_list')
    else:
        form = PasswordResetForm()
    return render(request, 'studyroom/admin/user_reset_password.html', {'form': form, 'target': target})


# ================================================================
#  管理员侧 - 自习室管理（增删改查）
# ================================================================

@user_passes_test(is_admin)
def manage_rooms(request):
    rooms = StudyRoom.objects.all().annotate(
        seat_count=Count('seats'),
        occupied_count=Count('seats', filter=Q(seats__status__in=['reserved', 'occupied']))
    )
    return render(request, 'studyroom/admin/rooms.html', {'rooms': rooms})


@user_passes_test(is_admin)
def add_room(request):
    if request.method == 'POST':
        form = StudyRoomForm(request.POST)
        if form.is_valid():
            room = form.save()
            for i in range(1, room.capacity + 1):
                Seat.objects.create(room=room, seat_no=f'{i:03d}')
            messages.success(request, f'自习室「{room.name}」已创建，自动生成 {room.capacity} 个座位')
            return redirect('manage_rooms')
    else:
        form = StudyRoomForm()
    return render(request, 'studyroom/admin/room_form.html', {'form': form, 'mode': 'add'})


@user_passes_test(is_admin)
def edit_room(request, room_id):
    room = get_object_or_404(StudyRoom, id=room_id)
    old_capacity = room.capacity
    if request.method == 'POST':
        form = StudyRoomForm(request.POST, instance=room)
        if form.is_valid():
            room = form.save()
            diff = room.capacity - old_capacity
            if diff > 0:
                existing = room.seats.count()
                for i in range(existing + 1, existing + diff + 1):
                    Seat.objects.create(room=room, seat_no=f'{i:03d}')
            messages.success(request, f'自习室「{room.name}」已更新')
            return redirect('manage_rooms')
    else:
        form = StudyRoomForm(instance=room)
    return render(request, 'studyroom/admin/room_form.html', {'form': form, 'mode': 'edit', 'room': room})


@user_passes_test(is_admin)
def delete_room(request, room_id):
    room = get_object_or_404(StudyRoom, id=room_id)
    if request.method == 'POST':
        room.delete()
        messages.success(request, '自习室及关联座位已删除')
        return redirect('manage_rooms')
    return render(request, 'studyroom/admin/room_confirm_delete.html', {'room': room})


# ================================================================
#  管理员侧 - 座位管理
# ================================================================

@user_passes_test(is_admin)
def seat_manage(request, room_id):
    room = get_object_or_404(StudyRoom, id=room_id)
    seats = room.seats.all().order_by('seat_no')
    return render(request, 'studyroom/admin/seat_manage.html', {'room': room, 'seats': seats})


@user_passes_test(is_admin)
def seat_add(request, room_id):
    room = get_object_or_404(StudyRoom, id=room_id)
    if request.method == 'POST':
        form = SeatForm(request.POST)
        if form.is_valid():
            seat = form.save(commit=False)
            seat.room = room
            try:
                seat.save()
                messages.success(request, f'座位 {seat.seat_no} 已添加')
            except Exception:
                messages.error(request, '座位号已存在')
            return redirect('seat_manage', room_id=room.id)
    else:
        form = SeatForm()
    return render(request, 'studyroom/admin/seat_form.html', {'form': form, 'room': room})


@user_passes_test(is_admin)
def seat_edit(request, seat_id):
    seat = get_object_or_404(Seat, id=seat_id)
    if request.method == 'POST':
        form = SeatForm(request.POST, instance=seat)
        if form.is_valid():
            form.save()
            messages.success(request, '座位信息已更新')
            return redirect('seat_manage', room_id=seat.room.id)
    else:
        form = SeatForm(instance=seat)
    return render(request, 'studyroom/admin/seat_form.html', {'form': form, 'room': seat.room})


@user_passes_test(is_admin)
def seat_delete(request, seat_id):
    seat = get_object_or_404(Seat, id=seat_id)
    room_id = seat.room.id
    if request.method == 'POST':
        seat.delete()
        messages.success(request, '座位已删除')
        return redirect('seat_manage', room_id=room_id)
    return render(request, 'studyroom/admin/seat_confirm_delete.html', {'seat': seat})


# ================================================================
#  管理员侧 - 预约记录 & 违规管理
# ================================================================

@user_passes_test(is_admin)
def reservation_records(request):
    records = Reservation.objects.all().select_related('user', 'seat', 'seat__room')
    status_filter = request.GET.get('status', '')
    if status_filter:
        records = records.filter(status=status_filter)
    return render(request, 'studyroom/admin/reservations.html', {
        'records': records, 'status_filter': status_filter,
    })


@user_passes_test(is_admin)
def delete_reservation(request, reservation_id):
    r = get_object_or_404(Reservation, id=reservation_id)
    if request.method == 'POST':
        r.delete()
        messages.success(request, '预约记录已删除')
        return redirect('reservation_records')
    return render(request, 'studyroom/admin/reservation_confirm_delete.html', {'r': r})


@user_passes_test(is_admin)
def violation_list(request):
    violations = Violation.objects.all().select_related('user', 'reservation')
    return render(request, 'studyroom/admin/violation_list.html', {'violations': violations})


@user_passes_test(is_admin)
def violation_add(request):
    if request.method == 'POST':
        form = ViolationForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, '违规记录已添加')
            return redirect('violation_list')
    else:
        form = ViolationForm()
    return render(request, 'studyroom/admin/violation_form.html', {'form': form})


@user_passes_test(is_admin)
def violation_delete(request, violation_id):
    v = get_object_or_404(Violation, id=violation_id)
    if request.method == 'POST':
        v.delete()
        messages.success(request, '违规记录已删除')
        return redirect('violation_list')
    return render(request, 'studyroom/admin/violation_confirm_delete.html', {'v': v})


# ================================================================
#  管理员侧 - 图书管理
# ================================================================

@user_passes_test(is_admin)
def manage_books(request):
    from django.core.paginator import Paginator
    q = request.GET.get('q', '').strip()
    books = Book.objects.all()
    if q:
        books = books.filter(Q(title__icontains=q) | Q(author__icontains=q) | Q(isbn__icontains=q))
    page_obj = Paginator(books, 15).get_page(request.GET.get('page'))
    return render(request, 'studyroom/admin/books.html', {
        'books': page_obj,
        'page_obj': page_obj,
        'q': q,
    })


@user_passes_test(is_admin)
def add_book(request):
    if request.method == 'POST':
        form = BookForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, '图书已入库')
            return redirect('manage_books')
    else:
        form = BookForm()
    return render(request, 'studyroom/admin/book_form.html', {'form': form, 'mode': 'add'})


@user_passes_test(is_admin)
def edit_book(request, book_id):
    book = get_object_or_404(Book, id=book_id)
    if request.method == 'POST':
        form = BookForm(request.POST, instance=book)
        if form.is_valid():
            form.save()
            messages.success(request, f'图书《{book.title}》已更新')
            return redirect('manage_books')
    else:
        form = BookForm(instance=book)
    return render(request, 'studyroom/admin/book_form.html', {'form': form, 'mode': 'edit', 'book': book})


@user_passes_test(is_admin)
def delete_book(request, book_id):
    book = get_object_or_404(Book, id=book_id)
    if request.method == 'POST':
        book.delete()
        messages.success(request, '图书已删除')
        return redirect('manage_books')
    return render(request, 'studyroom/admin/book_confirm_delete.html', {'book': book})


@user_passes_test(is_admin)
def borrow_records(request):
    from django.core.paginator import Paginator
    records = BorrowRecord.objects.all().select_related('user', 'book')
    status_filter = request.GET.get('status', '')
    if status_filter:
        records = records.filter(status=status_filter)
    page_obj = Paginator(records, 15).get_page(request.GET.get('page'))
    return render(request, 'studyroom/admin/borrows.html', {
        'records': page_obj,
        'page_obj': page_obj,
        'status_filter': status_filter,
    })


# ================================================================
#  管理员侧 - 饮品管理
# ================================================================

@user_passes_test(is_admin)
def manage_drinks(request):
    drinks = Drink.objects.all()
    return render(request, 'studyroom/admin/drinks.html', {'drinks': drinks})


@user_passes_test(is_admin)
def add_drink(request):
    if request.method == 'POST':
        form = DrinkForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, '饮品已上架')
            return redirect('manage_drinks')
    else:
        form = DrinkForm()
    return render(request, 'studyroom/admin/drink_form.html', {'form': form, 'mode': 'add'})


@user_passes_test(is_admin)
def edit_drink(request, drink_id):
    drink = get_object_or_404(Drink, id=drink_id)
    if request.method == 'POST':
        form = DrinkForm(request.POST, instance=drink)
        if form.is_valid():
            form.save()
            messages.success(request, f'饮品「{drink.name}」已更新')
            return redirect('manage_drinks')
    else:
        form = DrinkForm(instance=drink)
    return render(request, 'studyroom/admin/drink_form.html', {'form': form, 'mode': 'edit', 'drink': drink})


@user_passes_test(is_admin)
def delete_drink(request, drink_id):
    drink = get_object_or_404(Drink, id=drink_id)
    if request.method == 'POST':
        drink.delete()
        messages.success(request, '饮品已删除')
        return redirect('manage_drinks')
    return render(request, 'studyroom/admin/drink_confirm_delete.html', {'drink': drink})


@user_passes_test(is_admin)
def drink_orders(request):
    from django.core.paginator import Paginator
    orders = DrinkOrder.objects.all().select_related('user', 'drink')
    status_filter = request.GET.get('status', '')
    if status_filter:
        orders = orders.filter(status=status_filter)
    page_obj = Paginator(orders, 15).get_page(request.GET.get('page'))
    return render(request, 'studyroom/admin/drink_orders.html', {
        'orders': page_obj,
        'page_obj': page_obj,
        'status_filter': status_filter,
    })


@user_passes_test(is_admin)
def drink_order_complete(request, order_id):
    order = get_object_or_404(DrinkOrder, id=order_id)
    if request.method == 'POST' and order.status == 'pending':
        order.status = 'completed'
        order.save()
        messages.success(request, f'订单 {order.pickup_code} 已完成')
    return redirect('drink_orders')
