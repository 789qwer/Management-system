"""表单定义。"""
from django import forms
from django.contrib.auth.hashers import make_password

from .models import Book, Drink, Reservation, Seat, StudyRoom, User, Violation


class UserRegistrationForm(forms.Form):
    """学生注册表单：用户名 + 密码(两次) + 手机号 + 验证码。"""

    username = forms.CharField(
        label='用户名', max_length=150,
        widget=forms.TextInput(attrs={
            'class': 'form-control form-control-lg',
            'placeholder': '请输入用户名',
            'autocomplete': 'username',
        }),
    )
    password = forms.CharField(
        label='密码', min_length=6,
        widget=forms.PasswordInput(attrs={
            'class': 'form-control form-control-lg',
            'placeholder': '至少6个字符',
            'autocomplete': 'new-password',
        }),
    )
    password_confirm = forms.CharField(
        label='确认密码',
        widget=forms.PasswordInput(attrs={
            'class': 'form-control form-control-lg',
            'placeholder': '请再次输入密码',
            'autocomplete': 'new-password',
        }),
    )
    phone = forms.CharField(
        label='手机号', max_length=11,
        widget=forms.TextInput(attrs={
            'class': 'form-control form-control-lg',
            'placeholder': '请输入11位手机号',
        }),
    )
    captcha = forms.CharField(
        label='验证码', max_length=10,
        widget=forms.TextInput(attrs={
            'class': 'form-control form-control-lg',
            'placeholder': '请输入验证码',
            'autocomplete': 'off',
            'maxlength': '4',
        }),
    )

    def clean_username(self):
        username = self.cleaned_data.get('username', '').strip()
        if User.objects.filter(username=username).exists():
            raise forms.ValidationError('该用户名已被注册')
        return username

    def clean_phone(self):
        phone = self.cleaned_data.get('phone', '').strip()
        if not phone.isdigit() or len(phone) != 11:
            raise forms.ValidationError('请输入有效的11位手机号')
        return phone

    def clean(self):
        cleaned_data = super().clean()
        pwd = cleaned_data.get('password')
        pwd2 = cleaned_data.get('password_confirm')
        if pwd and pwd2 and pwd != pwd2:
            raise forms.ValidationError({'password_confirm': '两次输入的密码不一致'})
        return cleaned_data

    def save(self):
        """创建学生用户。"""
        user = User(
            username=self.cleaned_data['username'],
            phone=self.cleaned_data['phone'],
            role='student',
        )
        user.set_password(self.cleaned_data['password'])
        user.save()
        return user


class UserAddForm(forms.ModelForm):
    """管理员新增用户表单。"""

    password = forms.CharField(
        label='密码', widget=forms.PasswordInput,
        help_text='密码至少 6 个字符'
    )

    class Meta:
        model = User
        fields = ('username', 'student_id', 'role', 'phone', 'college', 'email', 'is_active')

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.widget.attrs.setdefault('class', 'form-control')
        self.fields['password'].widget.attrs['class'] = 'form-control'

    def clean_password(self):
        pwd = self.cleaned_data.get('password', '')
        if len(pwd) < 6:
            raise forms.ValidationError('密码至少 6 个字符')
        return pwd

    def save(self, commit=True):
        user = super().save(commit=False)
        user.password = make_password(self.cleaned_data['password'])
        if commit:
            user.save()
        return user


class UserEditForm(forms.ModelForm):
    """管理员编辑用户表单（不直接改密码，单独处理）。"""

    class Meta:
        model = User
        fields = ('username', 'student_id', 'role', 'phone', 'college', 'email', 'is_active')

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.widget.attrs.setdefault('class', 'form-control')


class PasswordResetForm(forms.Form):
    """管理员重置用户密码。"""

    new_password = forms.CharField(
        label='新密码', widget=forms.PasswordInput,
        help_text='密码至少 6 个字符'
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['new_password'].widget.attrs.setdefault('class', 'form-control')

    def clean_new_password(self):
        pwd = self.cleaned_data.get('new_password', '')
        if len(pwd) < 6:
            raise forms.ValidationError('密码至少 6 个字符')
        return pwd


class StudyRoomForm(forms.ModelForm):
    """自习室表单。"""

    class Meta:
        model = StudyRoom
        fields = ['name', 'location', 'capacity', 'open_time', 'close_time', 'status']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control'}),
            'location': forms.TextInput(attrs={'class': 'form-control'}),
            'capacity': forms.NumberInput(attrs={'class': 'form-control', 'min': 0}),
            'open_time': forms.TimeInput(attrs={'type': 'time', 'class': 'form-control'}),
            'close_time': forms.TimeInput(attrs={'type': 'time', 'class': 'form-control'}),
            'status': forms.Select(attrs={'class': 'form-select'}),
        }


class SeatForm(forms.ModelForm):
    """座位表单。"""

    class Meta:
        model = Seat
        fields = ['seat_no', 'status']
        widgets = {
            'seat_no': forms.TextInput(attrs={'class': 'form-control', 'placeholder': '如：001'}),
            'status': forms.Select(attrs={'class': 'form-select'}),
        }


class ReservationForm(forms.ModelForm):
    """预约表单。"""

    class Meta:
        model = Reservation
        fields = ['date', 'start_time', 'end_time']
        widgets = {
            'date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'start_time': forms.TimeInput(attrs={'type': 'time', 'class': 'form-control'}),
            'end_time': forms.TimeInput(attrs={'type': 'time', 'class': 'form-control'}),
        }


class ViolationForm(forms.ModelForm):
    """违规记录表单（管理员手动添加）。"""

    class Meta:
        model = Violation
        fields = ['user', 'type', 'description', 'penalty_points']
        widgets = {
            'user': forms.Select(attrs={'class': 'form-select'}),
            'type': forms.Select(attrs={'class': 'form-select'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
            'penalty_points': forms.NumberInput(attrs={'class': 'form-control', 'min': 1}),
        }


class BookForm(forms.ModelForm):
    """图书表单（管理员维护）。"""

    class Meta:
        model = Book
        fields = ['title', 'author', 'isbn', 'category', 'publisher',
                  'total_copies', 'available_copies', 'location', 'description']
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control', 'placeholder': '如：Python编程：从入门到实践'}),
            'author': forms.TextInput(attrs={'class': 'form-control', 'placeholder': '如：埃里克·马瑟斯'}),
            'isbn': forms.TextInput(attrs={'class': 'form-control', 'placeholder': '选填'}),
            'category': forms.Select(attrs={'class': 'form-select'}),
            'publisher': forms.TextInput(attrs={'class': 'form-control', 'placeholder': '选填'}),
            'total_copies': forms.NumberInput(attrs={'class': 'form-control', 'min': 0}),
            'available_copies': forms.NumberInput(attrs={'class': 'form-control', 'min': 0}),
            'location': forms.TextInput(attrs={'class': 'form-control', 'placeholder': '如：图书馆A区-3排-2架'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'rows': 3, 'placeholder': '图书简介（选填）'}),
        }

    def clean(self):
        cleaned_data = super().clean()
        total = cleaned_data.get('total_copies', 0)
        available = cleaned_data.get('available_copies', 0)
        if available > total:
            raise forms.ValidationError('可借数量不能大于馆藏总数')
        return cleaned_data


class DrinkForm(forms.ModelForm):
    """饮品表单（管理员维护）。"""

    class Meta:
        model = Drink
        fields = ['name', 'category', 'price', 'description', 'is_available']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': '如：美式咖啡'}),
            'category': forms.Select(attrs={'class': 'form-select'}),
            'price': forms.NumberInput(attrs={'class': 'form-control', 'min': 0, 'step': '0.01'}),
            'description': forms.TextInput(attrs={'class': 'form-control', 'placeholder': '一句话描述（选填）'}),
            'is_available': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        }
