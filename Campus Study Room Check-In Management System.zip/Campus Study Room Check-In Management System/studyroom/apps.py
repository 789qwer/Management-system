"""App 配置。"""
from django.apps import AppConfig


class StudyroomConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'studyroom'
    verbose_name = '自习室签到管理'
