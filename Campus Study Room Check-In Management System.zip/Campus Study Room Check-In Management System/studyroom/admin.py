"""Admin 后台注册。"""
from django.contrib import admin

from .models import (
    Book, BorrowRecord, Drink, DrinkOrder,
    Reservation, Seat, StudyRoom, User, Violation,
)


@admin.register(User)
class UserAdmin(admin.ModelAdmin):
    list_display = ('username', 'student_id', 'role', 'phone', 'college')
    list_filter = ('role',)
    search_fields = ('username', 'student_id')


@admin.register(StudyRoom)
class StudyRoomAdmin(admin.ModelAdmin):
    list_display = ('name', 'location', 'capacity', 'open_time', 'close_time', 'status')
    list_filter = ('status',)


@admin.register(Seat)
class SeatAdmin(admin.ModelAdmin):
    list_display = ('room', 'seat_no', 'status')
    list_filter = ('status', 'room')


@admin.register(Reservation)
class ReservationAdmin(admin.ModelAdmin):
    list_display = ('user', 'seat', 'date', 'start_time', 'end_time', 'status')
    list_filter = ('status', 'date')
    search_fields = ('user__username',)


@admin.register(Violation)
class ViolationAdmin(admin.ModelAdmin):
    list_display = ('user', 'type', 'penalty_points', 'created_at')
    list_filter = ('type',)


# ================================================================
#  图书借阅
# ================================================================

@admin.register(Book)
class BookAdmin(admin.ModelAdmin):
    list_display = ('title', 'author', 'category', 'isbn', 'available_copies', 'total_copies', 'location')
    list_filter = ('category',)
    search_fields = ('title', 'author', 'isbn')


@admin.register(BorrowRecord)
class BorrowRecordAdmin(admin.ModelAdmin):
    list_display = ('user', 'book', 'borrowed_at', 'due_at', 'returned_at', 'status')
    list_filter = ('status',)
    search_fields = ('user__username', 'book__title')


# ================================================================
#  饮品吧
# ================================================================

@admin.register(Drink)
class DrinkAdmin(admin.ModelAdmin):
    list_display = ('name', 'category', 'price', 'is_available')
    list_filter = ('category', 'is_available')
    search_fields = ('name',)


@admin.register(DrinkOrder)
class DrinkOrderAdmin(admin.ModelAdmin):
    list_display = ('pickup_code', 'user', 'drink', 'quantity', 'total_price', 'status', 'created_at')
    list_filter = ('status',)
    search_fields = ('user__username', 'pickup_code')
