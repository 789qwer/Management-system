"""数据模型 - 校园自习室签到管理系统。"""
from django.contrib.auth.models import AbstractUser
from django.db import models
from django.utils import timezone


class User(AbstractUser):
    """自定义用户：支持学生 / 管理员双角色。"""

    ROLE_CHOICES = (
        ('student', '学生'),
        ('admin', '管理员'),
    )
    role = models.CharField('角色', max_length=10, choices=ROLE_CHOICES, default='student')
    student_id = models.CharField('学号', max_length=20, unique=True, blank=True, null=True)
    phone = models.CharField('手机号', max_length=11, blank=True)
    college = models.CharField('学院', max_length=50, blank=True)

    class Meta:
        verbose_name = '用户'
        verbose_name_plural = '用户'

    @property
    def is_admin_role(self):
        return self.role == 'admin'

    def __str__(self):
        return f'{self.username}({self.get_role_display()})'


class StudyRoom(models.Model):
    """图书馆阅览室/自习室。"""

    STATUS_CHOICES = (
        ('open', '开放'),
        ('closed', '关闭'),
        ('maintenance', '维护中'),
    )
    BOOK_CATEGORY_CHOICES = (
        ('general', '综合图书'),
        ('literature', '文学'),
        ('science', '科技'),
        ('history', '历史'),
        ('art', '艺术'),
        ('periodical', '报刊杂志'),
        ('reference', '工具书'),
        ('study', '纯自习区'),
    )
    name = models.CharField('名称', max_length=50)
    floor = models.PositiveIntegerField('楼层', default=1)
    location = models.CharField('位置', max_length=100, blank=True)
    book_category = models.CharField('图书分类', max_length=20, choices=BOOK_CATEGORY_CHOICES, default='general')
    description = models.CharField('房间描述', max_length=200, blank=True)
    capacity = models.PositiveIntegerField('容纳人数', default=0)
    open_time = models.TimeField('开放时间')
    close_time = models.TimeField('关闭时间')
    # 自定义布局：每行为 {"count": 座位数, "aisle_after": 走道位置或 null}
    layout = models.JSONField('座位布局', default=dict, blank=True)
    # 书柜布局：[{"x":50,"y":10,"w":40,"h":6,"label":"文学书架"}]
    shelves = models.JSONField('书柜布局', default=list, blank=True)
    status = models.CharField('状态', max_length=15, choices=STATUS_CHOICES, default='open')
    created_at = models.DateTimeField('创建时间', auto_now_add=True)

    class Meta:
        verbose_name = '阅览空间'
        verbose_name_plural = '阅览空间'
        ordering = ['floor', 'name']

    def __str__(self):
        return f'{self.floor}F · {self.name}'


class Seat(models.Model):
    """阅览空间座位。"""

    STATUS_CHOICES = (
        ('available', '可用'),
        ('reserved', '已预约'),
        ('occupied', '使用中'),
        ('unavailable', '不可用'),
    )
    room = models.ForeignKey(StudyRoom, on_delete=models.CASCADE, related_name='seats', verbose_name='阅览空间')
    seat_no = models.CharField('座位号', max_length=10, help_text='如 1A、2B')
    # 座位在平面图上的百分比坐标 (0~100)，用于自由布局
    position_x = models.FloatField('X坐标(%)', default=0)
    position_y = models.FloatField('Y坐标(%)', default=0)
    status = models.CharField('状态', max_length=15, choices=STATUS_CHOICES, default='available')

    class Meta:
        verbose_name = '座位'
        verbose_name_plural = '座位'
        unique_together = ('room', 'seat_no')
        ordering = ['position_y', 'position_x']

    def __str__(self):
        return f'{self.room.name}-{self.seat_no}'


class Reservation(models.Model):
    """预约记录。"""

    STATUS_CHOICES = (
        ('pending', '待签到'),
        ('active', '使用中'),
        ('completed', '已完成'),
        ('cancelled', '已取消'),
        ('noshow', '爽约'),
    )
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='reservations', verbose_name='用户')
    seat = models.ForeignKey(Seat, on_delete=models.CASCADE, related_name='reservations', verbose_name='座位')
    date = models.DateField('日期')
    start_time = models.TimeField('开始时间')
    end_time = models.TimeField('结束时间')
    status = models.CharField('状态', max_length=15, choices=STATUS_CHOICES, default='pending')
    sign_in_time = models.DateTimeField('签到时间', null=True, blank=True)
    sign_out_time = models.DateTimeField('签退时间', null=True, blank=True)
    created_at = models.DateTimeField('创建时间', auto_now_add=True)

    class Meta:
        verbose_name = '预约'
        verbose_name_plural = '预约'
        ordering = ['-created_at']

    def __str__(self):
        return f'{self.user.username} - {self.seat} - {self.date}'


class Violation(models.Model):
    """违规记录。"""

    VIOLATION_TYPES = (
        ('noshow', '预约未签到'),
        ('late', '迟到签到'),
        ('early_leave', '早退'),
        ('other', '其他'),
    )
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='violations', verbose_name='用户')
    reservation = models.ForeignKey(
        Reservation, on_delete=models.SET_NULL, null=True, blank=True, verbose_name='关联预约'
    )
    type = models.CharField('违规类型', max_length=15, choices=VIOLATION_TYPES)
    description = models.TextField('描述', blank=True)
    penalty_points = models.IntegerField('扣分', default=1)
    created_at = models.DateTimeField('记录时间', auto_now_add=True)

    class Meta:
        verbose_name = '违规记录'
        verbose_name_plural = '违规记录'

    def __str__(self):
        return f'{self.user.username}-{self.get_type_display()}'


# ================================================================
#  图书借阅模块
# ================================================================

class Book(models.Model):
    """图书。"""

    CATEGORY_CHOICES = (
        ('computer', '计算机'),
        ('literature', '文学'),
        ('science', '科技'),
        ('economy', '经管'),
        ('foreign', '外语'),
        ('other', '其他'),
    )
    title = models.CharField('书名', max_length=200)
    author = models.CharField('作者', max_length=100)
    isbn = models.CharField('ISBN', max_length=20, blank=True)
    category = models.CharField('分类', max_length=20, choices=CATEGORY_CHOICES, default='other')
    publisher = models.CharField('出版社', max_length=100, blank=True)
    total_copies = models.PositiveIntegerField('馆藏总数', default=1)
    available_copies = models.PositiveIntegerField('可借数量', default=1)
    location = models.CharField('馆藏位置', max_length=100, blank=True)
    description = models.TextField('简介', blank=True)
    created_at = models.DateTimeField('入库时间', auto_now_add=True)

    class Meta:
        verbose_name = '图书'
        verbose_name_plural = '图书'
        ordering = ['-created_at']

    def __str__(self):
        return f'{self.title}({self.author})'

    @property
    def is_borrowable(self):
        return self.available_copies > 0

    @property
    def category_color(self):
        return {
            'computer': 'primary', 'literature': 'success', 'science': 'info',
            'economy': 'warning', 'foreign': 'danger',
        }.get(self.category, 'secondary')

    @property
    def category_icon(self):
        return {
            'computer': 'bi-code-slash', 'literature': 'bi-feather', 'science': 'bi-rocket-takeoff',
            'economy': 'bi-graph-up-arrow', 'foreign': 'bi-translate',
        }.get(self.category, 'bi-book')


class BorrowRecord(models.Model):
    """图书借阅记录。"""

    STATUS_CHOICES = (
        ('borrowing', '借阅中'),
        ('returned', '已归还'),
    )
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='borrow_records', verbose_name='借阅人')
    book = models.ForeignKey(Book, on_delete=models.CASCADE, related_name='borrow_records', verbose_name='图书')
    borrowed_at = models.DateTimeField('借出时间', auto_now_add=True)
    due_at = models.DateTimeField('应还时间')
    returned_at = models.DateTimeField('归还时间', null=True, blank=True)
    renew_count = models.PositiveIntegerField('续借次数', default=0)
    status = models.CharField('状态', max_length=15, choices=STATUS_CHOICES, default='borrowing')

    class Meta:
        verbose_name = '借阅记录'
        verbose_name_plural = '借阅记录'
        ordering = ['-borrowed_at']
        constraints = [
            models.UniqueConstraint(
                fields=['user', 'book'],
                condition=models.Q(status='borrowing'),
                name='unique_active_borrow',
            ),
        ]

    def __str__(self):
        return f'{self.user.username} 借阅 {self.book.title}'

    @property
    def is_overdue(self):
        """是否逾期（未归还且超过应还时间）。"""
        return self.status == 'borrowing' and timezone.now() > self.due_at


# ================================================================
#  饮品吧模块
# ================================================================

class Drink(models.Model):
    """饮品。"""

    CATEGORY_CHOICES = (
        ('coffee', '咖啡'),
        ('tea', '茶饮'),
        ('juice', '果汁'),
        ('snack', '小食'),
    )
    name = models.CharField('名称', max_length=50)
    category = models.CharField('分类', max_length=20, choices=CATEGORY_CHOICES, default='tea')
    price = models.DecimalField('价格', max_digits=6, decimal_places=2)
    description = models.CharField('描述', max_length=200, blank=True)
    is_available = models.BooleanField('在售', default=True)
    created_at = models.DateTimeField('上架时间', auto_now_add=True)

    class Meta:
        verbose_name = '饮品'
        verbose_name_plural = '饮品'
        ordering = ['category', 'price']

    def __str__(self):
        return self.name

    @property
    def category_icon(self):
        return {
            'coffee': 'bi-cup-hot-fill', 'tea': 'bi-cup-straw',
            'juice': 'bi-droplet-fill', 'snack': 'bi-cookie',
        }.get(self.category, 'bi-cup')


class DrinkOrder(models.Model):
    """饮品订单。"""

    STATUS_CHOICES = (
        ('pending', '制作中'),
        ('completed', '已完成'),
        ('cancelled', '已取消'),
    )
    SUGAR_CHOICES = (
        ('sugar_free', '无糖'),
        ('less_sugar', '少糖'),
        ('half_sugar', '半糖'),
        ('more_sugar', '多糖'),
        ('full_sugar', '全糖'),
    )
    TEMP_CHOICES = (
        ('no_ice', '去冰'),
        ('less_ice', '少冰'),
        ('normal_ice', '正常冰'),
        ('hot', '热饮'),
    )
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='drink_orders', verbose_name='下单人')
    drink = models.ForeignKey(Drink, on_delete=models.CASCADE, related_name='orders', verbose_name='饮品')
    quantity = models.PositiveIntegerField('数量', default=1)
    sweetness = models.CharField('甜度', max_length=15, choices=SUGAR_CHOICES, default='half_sugar')
    temperature = models.CharField('温度', max_length=15, choices=TEMP_CHOICES, default='normal_ice')
    total_price = models.DecimalField('总价', max_digits=8, decimal_places=2)
    pickup_code = models.CharField('取餐码', max_length=10)
    status = models.CharField('状态', max_length=15, choices=STATUS_CHOICES, default='pending')
    note = models.CharField('备注', max_length=100, blank=True)
    created_at = models.DateTimeField('下单时间', auto_now_add=True)

    class Meta:
        verbose_name = '饮品订单'
        verbose_name_plural = '饮品订单'
        ordering = ['-created_at']

    def __str__(self):
        return f'{self.user.username} - {self.drink.name} x{self.quantity}'
